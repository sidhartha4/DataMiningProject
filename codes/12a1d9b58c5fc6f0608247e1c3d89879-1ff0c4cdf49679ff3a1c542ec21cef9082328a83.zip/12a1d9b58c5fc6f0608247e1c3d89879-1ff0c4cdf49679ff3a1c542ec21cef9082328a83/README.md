# PyTorch Logistic Regression ~ MLP model

1. logistic_regression.py - Using torch.nn module, analysing sklearn DIGITS dataset
2. logistic_regression_low.py - NOT using torch.nn module, analysing sklearn DIGITS dataset
3. mnist_mlp.py
